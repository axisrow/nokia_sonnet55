Screenshots for the bugs listed in the issue. Folder = bug number. before-* = main, after-* = PR #2.
LCD captures are 672x384 (84x48 dots, 8 px each).
